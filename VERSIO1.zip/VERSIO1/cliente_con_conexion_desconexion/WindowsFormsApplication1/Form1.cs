﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using Libreria;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        Socket server;
        Funciones funciones = new Funciones();
        Boolean Conexion = false;
       
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            groupBox1.Visible = false;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (ConQuienJuego.Checked)
            {
                //Consulta 1
                // Busca los jugadores con los que ha jugado la persona que introduces por consola
                string mensaje = funciones.ConQuienJuego(ID.Text, server);
                MessageBox.Show("Has jugado con: " + mensaje);
            }
            else if (MasPuntos.Checked)
            {
                //Consulta 2
                //Busca que jugador que ha jugado en la partida introducida por consola tiene mas puntos acumulados
                string mensaje = funciones.QuienTieneMasPuntos(partida.Text, server);
                MessageBox.Show("El jugador con más puntos es: " + mensaje);

            }
            else
            {
                //Consulta 3
                // Busca la partida mas corta y que su tiempo es inferior a 1500s
                string mensaje = funciones.PartidaMasCorta(server);
                MessageBox.Show(mensaje);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Mensaje de desconexión
            string mensaje = "0/";

            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            // Nos desconectamos
            this.BackColor = Color.Gray;
            server.Shutdown(SocketShutdown.Both);
            server.Close();
            //funciones.Desconnectar(server);
            this.BackColor = Color.Gray;
            groupBox1.Visible = false;
            Conexion = false;


        }

        private void Login_Click(object sender, EventArgs e)
        {
            //Log in
            if (Conexion ==false)
            {
                //Nos permite comprobar que el usuario y la contraseña introducidos existen en la base de datos
                //Creamos un IPEndPoint con el ip del servidor y puerto del servidor 
                //al que deseamos conectarnos
                IPAddress direc = IPAddress.Parse("192.168.56.101");
                IPEndPoint ipep = new IPEndPoint(direc, 9270);
                Conexion = true;

                //Creamos el socket 
                server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                //Boolean conectado = funciones.Connectar();
                try
                {
                    server.Connect(ipep);//Intentamos conectar el socket
                    this.BackColor = Color.Green;
                    MessageBox.Show("Conectado");

                    string mensaje = funciones.LogIn(UsuariLogIn.Text, contrasenyaLogIn.Text, server);

                    //Nos encontramos con 3 casos diferentes
                    if (mensaje == "NO EXISTE")
                        MessageBox.Show("Este usuario no existe, por favor regístrate");

                    else if (mensaje == "OK")
                    {
                        MessageBox.Show("Bienvenido a tu cuenta :)");
                        groupBox1.Visible = true;
                    }

                    else
                        MessageBox.Show("La contraseña introducida es incorrrecta");

                }
                catch (SocketException ex)
                {
                    //Si hay excepcion imprimimos error y salimos del programa con return 
                    MessageBox.Show("No he podido conectar con el servidor");
                    return;

                }
            }
            else
            {
                string mensaje = funciones.LogIn(UsuariLogIn.Text, contrasenyaLogIn.Text, server);

                //Nos encontramos con 3 casos diferentes
                if (mensaje == "NO EXISTE")
                    MessageBox.Show("Este usuario no existe, por favor regístrate");

                else if (mensaje == "OK")
                {
                    MessageBox.Show("Bienvenido a tu cuenta :)");
                    groupBox1.Visible = true;
                }

                else
                    MessageBox.Show("La contraseña introducida es incorrrecta");
            }
        }

        private void SignIn_Click(object sender, EventArgs e)
        {
            //Sign in
            if (Conexion == false)
            {
                //Nos permite añadir un nuevo usuario en la base de datos
                IPAddress direc = IPAddress.Parse("192.168.56.101");
                IPEndPoint ipep = new IPEndPoint(direc, 9270);

                //Creamos el socket 
                server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                //Boolean conectado = funciones.Connectar();
                Conexion = true;
                try
                {
                    server.Connect(ipep);//Intentamos conectar el socket
                    this.BackColor = Color.Green;
                    MessageBox.Show("Conectado");

                    string mensaje = funciones.SignIn(UsuariSignIn.Text, ContrasenyaSignIn.Text, server);

                    //Nos encontramos con 3 casos
                    if (mensaje == "ERROR")
                        MessageBox.Show("Ha habido un error, revisa bien los campos");
                    else if (mensaje == "OK")
                    {
                        MessageBox.Show("Registrado correctamente! Bienvenido :)");
                        groupBox1.Visible = true;
                    }
                    else
                        MessageBox.Show("Lo sentimos, ese usuario ya existe");
                }
                catch (SocketException ex)
                {
                    //Si hay excepcion imprimimos error y salimos del programa con return 
                    MessageBox.Show("No he podido conectar con el servidor");
                    return;

                }
            }
            else
            {
                string mensaje = funciones.SignIn(UsuariSignIn.Text, ContrasenyaSignIn.Text, server);

                //Nos encontramos con 3 casos
                if (mensaje == "ERROR")
                    MessageBox.Show("Ha habido un error, revisa bien los campos");
                else if (mensaje == "OK")
                {
                    MessageBox.Show("Registrado correctamente! Bienvenido :)");
                    groupBox1.Visible = true;
                }
                else
                    MessageBox.Show("Lo sentimos, ese usuario ya existe");
            }

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
     
    }
}
