﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;

namespace Libreria
{
    public class Funciones
    {
        public Boolean Connectar(Socket server)
        {
            //Creamos un IPEndPoint con el ip del servidor y puerto del servidor 
            //al que deseamos conectarnos
            IPAddress direc = IPAddress.Parse("192.168.56.101");
            IPEndPoint ipep = new IPEndPoint(direc, 9268);


            //Creamos el socket 
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                server.Connect(ipep);//Intentamos conectar el socket
                return true;
            }
            catch (SocketException ex)
            {
                return false;
            }
        }
        public string ConQuienJuego(string Nombre, Socket server)
        {
            string mensaje = "1/" + Nombre;
            // Enviamos al servidor el nombre tecleado
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            //Recibimos la respuesta del servidor
            byte[] msg2 = new byte[80];
            server.Receive(msg2);
            mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
            return mensaje;
        }

        public string QuienTieneMasPuntos(string Partida, Socket server)
        {
            string mensaje = "2/" + Partida;
            // Enviamos al servidor el ID de la partida tecleado
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            //Recibimos la respuesta del servidor
            byte[] msg2 = new byte[80];
            server.Receive(msg2);
            mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
            return mensaje;
        }

        public string PartidaMasCorta(Socket server)
        {
            string mensaje = "3/ ";
            // En este caso no es necesario introducir ningún dato extra
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            //Recibimos la respuesta del servidor
            byte[] msg2 = new byte[80];
            server.Receive(msg2);
            mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
            return mensaje;
        }

        public string LogIn(string Nombre, string Contrasenya, Socket server)
        {
            //Enviamos al servidor el nombre y la contraseña del usuario existente
            string mensaje = "4/" + Nombre + "/" + Contrasenya;
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            //Recibimos la respuesta del servidor
            byte[] msg2 = new byte[80];
            server.Receive(msg2);
            mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
            return mensaje;
        }
        public string SignIn(string Nombre, string Contrasenya, Socket server)
        {
            //Enviamos al servidor el nombre y la contraseña del usuario nuevo
            string mensaje = "5/" + Nombre + "/" + Contrasenya;
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            //Recibimos la respuesta del servidor
            byte[] msg2 = new byte[80];
            server.Receive(msg2);
            mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
            return mensaje;
        }


        //public void Desconnectar(Socket server)
        //{
        //    string mensaje = "0/";
        
        //    byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
        //    server.Send(msg);

        //    // Nos desconectamos
        //    server.Shutdown(SocketShutdown.Both);
        //    server.Close();
        //}
    }
}
